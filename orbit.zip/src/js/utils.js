
module.exports = { randomIntFromRange, randomColor, distance }
